import * as React from 'react';
import { Text, View, StyleSheet, Image } from 'react-native';

export default function () {
  return (
    <View style={styles.container}>
      <Text style={styles.paragraph}>
        A vaccine can prevent you from getting the COVID-19 virus or prevent you
        from becoming seriously ill if you get the COVID-19 virus. Also, if you
        are fully vaccinated, you can return to many activities you may not have
        been able to do because of the pandemic — including not wearing a mask
        or social distancing — except where required by a rule or law. However,
        if you are in an area with a high number of new COVID-19 cases in the
        last week, the CDC recommends wearing a mask indoors in public. If you
        are fully vaccinated and have a condition or are taking medications that
        weaken your immune system, you may need to keep wearing a mask. If you
        haven’t had the COVID-19 vaccine, you can take many steps to reduce your
        risk of infection. WHO and CDC recommend following these precautions for
        avoiding exposure to the virus that causes COVID-19: Avoid close contact
        (within about 6 feet, or 2 meters) with anyone who is sick or has
        symptoms. Keep distance between yourself and others (within about 6
        feet, or 2 meters). This is especially important if you have a higher
        risk of serious illness. Keep in mind some people may have COVID-19 and
        spread it to others, even if they don't have symptoms or don't know they
        have COVID-19. Avoid crowds and indoor places that have poor
        ventilation. Wash your hands often with soap and water for at least 20
        seconds, or use an alcohol-based hand sanitizer that contains at least
        60% alcohol. Wear a face mask in indoor public spaces and outdoors where
        there is a high risk of COVID-19 transmission, such as at a crowded
        event or large gathering. Further mask guidance differs depending on
        whether you are fully vaccinated or unvaccinated. Surgical masks may be
        used if available. N95 respirators should be reserved for health care
        providers. Cover your mouth and nose with your elbow or a tissue when
        you cough or sneeze. Throw away the used tissue. Wash your hands right
        away. Avoid touching your eyes, nose and mouth. Avoid sharing dishes,
        glasses, towels, bedding and other household items if you're sick. Clean
        and disinfect high-touch surfaces, such as doorknobs, light switches,
        electronics and counters, daily. Stay home from work, school and public
        areas if you're sick, unless you're going to get medical care. Avoid
        public transportation, taxis and ride-sharing if you're sick
      </Text>
      <Image style={styles.logo} source={require('../assets/covid11.jpg')} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    justifyContent: 'center',
    padding: 24,
    backgroundColor:'lightgreen',
    borderRadius:20,
  },
  paragraph: {
    margin: 24,
    marginTop: 0,
    fontSize: 14,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  logo: {
    height: 200,
    width: 200,
  },
});
