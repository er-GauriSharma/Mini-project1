import * as React from 'react';
import { Text, View, StyleSheet, Image ,Pressable} from 'react-native';

export default function Covid({ navigation,Loginpage}) {
  return (
    <View style={styles.container}>
      <Text style={styles.paragraph}>
        Welcome to the covid app .I hope this App will help you 
      
      </Text>
      <Text style={styles.paragraph}>
        I hope you safe and healthy at your home
      </Text>
          <Image style={styles.logo} source={require('../assets/covid4.png')} />
      <Pressable style={{marginTop:50,}}
      onPress={()=>{navigation.navigate('Login')}}>
      <Text style={styles.buttontext}>Login</Text>
      </Pressable>
      
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
  alignContent:'center',
  paddingBottom:40,
    borderRadius:50,
    paddingTop:40,
    backgroundColor:'orange',

  },
   buttontext:{
    fontSize:20,
    backgroundColor:'#fe8a71',
    paddingLeft:50,
    paddingRight:50,
    paddingBottom:10,
    paddingTop:10,
     textAlign:'center',
    
    borderRadius:60,
  },
  paragraph: {
    margin: 15,
    marginTop: 0,
    fontSize: 14,
    fontWeight: 'bold',
    textAlign: 'center',
    fontFamily:'cursive',
    backgroundColor:'gray',
    padding:20,
    borderRadius:80,
  },
  logo: {
height:230,
width:250,
    borderRadius:50,
  },
});
