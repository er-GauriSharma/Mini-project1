import * as React from 'react';
import { Text, View, StyleSheet, Image } from 'react-native';

export default function Symptoms() {
  return (
    <View style={styles.container}>
      <Text style={styles.headerText}> Symptoms</Text>
      <Text style={styles.paragraph}>
        Symptoms Signs and symptoms of coronavirus disease 2019 (COVID-19) may
        appear two to 14 days after exposure. This time after exposure and
        before having symptoms is called the incubation period. Common signs and
        symptoms can include: Fever Cough Tiredness Early symptoms of COVID-19
        may include a loss of taste or smell. Other symptoms can include:
        .Shortness of breath or difficulty breathing .Muscle aches .Chills .Sore
        throat .Runny nose .Headache .Chest pain .Pink eye (conjunctivitis)
        .Nausea .Vomiting .Diarrhea .Rash This list is not all inclusive.
        Children have similar symptoms to adults and generally have mild
        illness. The severity of COVID-19 symptoms can range from very mild to
        severe. Some people may have only a few symptoms, and some people may
        have no symptoms at all. Some people may experience worsened symptoms,
        such as worsened shortness of breath and pneumonia, about a week after
        symptoms start. People who are older have a higher risk of serious
        illness from COVID-19, and the risk increases with age. People who have
        existing medical conditions also may have a higher risk of serious
        illness. Certain medical conditions that may increase the risk of
        serious illness from COVID-19 include: Serious heart diseases, such as
        heart failure, coronary artery disease or cardiomyopathy Cancer Chronic
        obstructive pulmonary disease (COPD) Type 1 or type 2 diabetes
        Overweight, obesity or severe obesity High blood pressure Smoking
        Chronic kidney disease Sickle cell disease or thalassemia Weakened
        immune system from solid organ transplants Pregnancy Asthma Chronic lung
        diseases such as cystic fibrosis or pulmonary fibrosis Liver disease
        Dementia Down syndrome Weakened immune system from bone marrow
        transplant, HIV or some medications Brain and nervous system conditions
        Substance use disorders This list is not all inclusive. Other underlying
        medical conditions may increase your risk of serious illness from
        COVID-19.
      </Text>
      <Image style={styles.logo} source={require('../assets/covid8.jpg')} />
      <Text style={styles.headerText}> Causes</Text>
      <Text style={styles.paragraph}>
        Infection with the new coronavirus (severe acute respiratory syndrome
        coronavirus 2, or SARS-CoV-2) causes coronavirus disease 2019
        (COVID-19). The virus that causes COVID-19 spreads easily among people,
        and more continues to be discovered over time about how it spreads. Data
        has shown that it spreads mainly from person to person among those in
        close contact (within about 6 feet, or 2 meters). The virus spreads by
        respiratory droplets released when someone with the virus coughs,
        sneezes, breathes, sings or talks. These droplets can be inhaled or land
        in the mouth, nose or eyes of a person nearby. In some situations, the
        COVID-19 virus can spread by a person being exposed to small droplets or
        aerosols that stay in the air for several minutes or hours — called
        airborne transmission. It's not yet known how common it is for the virus
        to spread this way. It can also spread if a person touches a surface or
        object with the virus on it and then touches his or her mouth, nose or
        eyes, but the risk is low. Some reinfections of the virus that causes
        COVID-19 have happened, but these have been uncommon.
      </Text>
      <Image style={styles.logo} source={require('../assets/covid10.jpg')} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    justifyContent: 'center',
    padding: 24,
    backgroundColor:'orange',
  },
  headerText: {
    fontSize: 25,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  paragraph: {
    margin: 24,
    marginTop: 0,
    fontSize: 14,
    fontWeight: 'bold',
    textAlign: 'center',
    fontFamily: 'cursive',
  },
  logo: {
    height: 150,
    width: 200,
  },
});
