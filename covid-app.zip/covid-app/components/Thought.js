import * as React from 'react';
import { Text, View, StyleSheet, Image, ScrollView } from 'react-native';

export default function About() {
  return (
    <ScrollView>
      <View style={styles.container}>
        <Text style={styles.paragraph}>
          1)“Everybody goes through difficult times, but it is those who push
          through those difficult times who will eventually become successful in
          life. Don't give up, because this too shall pass.”
          <Text
            style={(styles.paragraph, { fontWeight: 'bold', fontsize: 20 })}>
            {' '}
            [Jeanette Coron]
          </Text>
        </Text>
        <Image style={styles.logo} source={require('../assets/covid.jpg')} />
        <Text
          style={
            (styles.paragraph,
            {
              textAlign: 'left',
              fontWeight: 'bold',
              margin: 30,
              paddingLeft: 0,
              fontFamily: 'cursive',
            })
          }>
          2) “Hard times don’t create heroes. It is during the hard times when
          the ‘hero’ within us is revealed.” – [Bob Riley]
        </Text>
        <Image style={styles.logo} source={require('../assets/covid.1.jpg')} />
        <Text style={styles.paragraph}>
          3)“Life is short, but it is wide. This too shall pass. 
          <Text
            style={(styles.paragraph, { fontWeight: 'bold', fontsize: 20 })}>
            {' '}
            [ Rebecca Wells]
          </Text>
        </Text>
          <Text style={styles.paragraph}>
          4)“When I look at the future, it's so bright it burns my eyes.”  
          <Text
            style={(styles.paragraph, { fontWeight: 'bold', fontsize: 20 })}>
            {' '}
            [  Oprah Winfrey.]
          </Text>
        </Text>
         <Text style={styles.paragraph}>
          4)“We do not need magic to change the world, we carry all the power we need inside ourselves already: we have the power to imagine better.” 
          <Text
            style={(styles.paragraph, { fontWeight: 'bold', fontsize: 20 })}>
            {' '}
            [ - J.K. Rowling.]
          </Text>
        </Text>
        <Image style={styles.logo} source={require('../assets/covid3.jpg')} />
         <Text style={styles.paragraph}>
          5)What good is an idea if it remains an idea? Try. Experiment. Iterate. Fail. Try again. Change the world.
          <Text
            style={(styles.paragraph, { fontWeight: 'bold', fontsize: 20 })}>
            {' '}
            [ – Simon Sinek.]
          </Text>
        </Text>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    justifyContent: 'center',
    padding: 24,
  },
  paragraph: {
   margin: 15,
    marginTop: 0,
    fontSize: 14,
    fontWeight: 'bold',
    textAlign: 'center',
    fontFamily:'cursive',
    
    padding:20,
  },
    logo: {
height:190,
width:300,
    },
    
});
