import React, { Component, useState,useEffect,db } from 'react';
import { View, Text, StyleSheet, TextInput, Pressable,ScrollView} from 'react-native';

import { Card } from 'react-native-paper';
import Icon from 'react-native-vector-icons/Entypo';
import { Input } from 'react-native-elements';




export default function Registration({ navigation, Home }) {
  const [arr, setItem] = useState([]);
  const [name, setName] = useState('');

  const [phone, setPhone] = useState('');
  
 
 const submitValue = () => {
  
    const details = {
      
     
      inputPhone: phone,

    };
    
    setItem([...arr, details]);
    console.log(arr);
  };
      
    
  return (

<ScrollView>

    <View style={styles.container}>
      <Card style={styles.header}>
        <Text style={styles.headerText}>Registration</Text>
       
      </Card>
      <View style={styles.registration}>
        
        <Input
          placeholder="Mobile no."
          leftIcon={<Icon name={'phone'} size={24} color="black" />}
          style={styles.inputText}
          onChangeText={(text) => {
            setMobileno(text);
          }}
        />
        <Input
          placeholder="passoword"
          leftIcon={<Icon name="lock" size={24} color="black" />}
          style={styles.inputText}
          onChangeText={(text) => {
            setPhone(text);
          }}
        />
       
      </View>
      <View style={styles.button}>
        <Pressable style={{marginTop:50,}}
      onPress={()=>{navigation.navigate('Home')}}>
      <Text style={styles.buttontext}>Get Register</Text>
      </Pressable>
      </View>
      
    </View>
    </ScrollView>
  );
}

  const styles = StyleSheet.create({
  container: {
    flex: 1,
    // borderColor: 'red',
    // borderWidth: 1,
  },
  buttontext:{
    fontSize:20,
    backgroundColor:'blue',
    padding:10,
    textAlign:'center'
  },
  header: {
    textAlign: 'center',
    padding: 10,
    position: 'absoulte',
  },
  headerText: {
    fontSize: 24,
    fontWeight: 'bold',
  },
  registration: {
    marginTop: 50,
  },
  buttonText: {
    fontSize: 20,
  },
  button: {
    justifyContent: 'center',
    textAlign: 'center',
    marginTop: 20,
  },
  buttonBox: {
    backgroundColor: 'lightblue',
    alignSelf: 'center',
    padding: 20,
  },
});
