import React, { Component } from 'react';
import { View, Text, StyleSheet, Pressable,Linking,TouchableOpacity,Image } from 'react-native';

import { Card } from 'react-native-paper';

export default function Vedio() {
  return (
    <View style={styles.container}>
      <Card>
        <Text style={styles.headerText}> Home</Text>
      </Card>
      <Card style={styles.welcome}>
        <Text style={styles.welcomeText}>
          Welcome to the Covid app .This App is provide a basic knowledge about
          Covid
        </Text>
      
      <TouchableOpacity
          style={styles.myButton}
          onPress={() => {Linking.openURL(' https://www.cdc.gov/coronavirus/2019-ncov/videos/visiting-friends-family-higher-risk/Visiting-Friends-and-Family-with-Higher-Risk-for-Severe-Illness.mp4')}}>
    <Text style={styles.headerText,{padding:20,fontSize:15} }>
          Click here to see Vedio</Text>
          </TouchableOpacity>
        
       <Image style={styles.logo} source={require('../assets/covid9.jpg')} />
        <Text style={styles.Text}>
          Coronaviruses are a family of viruses that can cause illnesses such as
          the common cold, severe acute respiratory syndrome (SARS) and Middle
          East respiratory syndrome (MERS). In 2019, a new coronavirus was
          identified as the cause of a disease outbreak that originated in
          China. The virus is now known as the severe acute respiratory syndrome
          coronavirus 2 (SARS-CoV-2). The disease it causes is called
          coronavirus disease 2019 (COVID-19). In March 2020, the World Health
          Organization (WHO) declared the COVID-19 outbreak a pandemic. Public
          health groups, including the U.S. Centers for Disease Control and
          Prevention (CDC) and WHO, are monitoring the pandemic and posting
          updates on their websites. These groups have also issued
          recommendations for preventing and treating the illness
        </Text>
      </Card>
    
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding:20,
  },

  headerText: {
    fontSize: 15,  
      fontWeight: 'bold',
    textAlign: 'center',
  },
  Text: {
    margin: 15,
    marginTop: 0,
    fontSize: 14,
    fontWeight: 'bold',
    textAlign: 'center',
    fontFamily: 'cursive',

    padding: 20,
  },
  welcomeText: {
    fontSize: 20,
    backgroundColor: 'orange',
    padding: 20,
    textAlign: 'center',
    paddingBottom:20,
  },
  myButton:{
    paddinTop:20,
    textAlign:'center',
    backgroundColor:'gray'

  }
});
