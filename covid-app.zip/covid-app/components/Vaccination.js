import React from 'react';
import {
  View,
  TextInput,
  StyleSheet,
  TouchableOpacity,
  Text,
  ScrollView,
} from 'react-native';
import DatePicker from 'react-native-datepicker';

class App extends React.Component {
  state = {
    pinCode: null,
    date: null,
    locations: [],
  };

  handlePinCode = value => {
    this.setState({
      pinCode: value,
    });
  };

  submit = () => {
    fetch(
      `https://cdn-api.co-vin.in/api/v2/appointment/sessions/public/findByPin?pincode=${this.state.pinCode}&date=${this.state.date}`,
      {
        method: 'GET',
        headers: {
          'User-Agent':
            'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.95 Safari/537.36',
        },
      },
    )
      .then(res => {
        return res.json();
      })
      .then(response => {
        this.setState({
          locations: response['sessions'],
        });
      })
      .catch(error => {
        console.log(error);
      });
  };

  render() {
    return (
      <View>
        <View style={{alignItems: 'center'}}>
          <TextInput
            placeholder="Enter the pincode"
            keyboardType={'number-pad'}
            style={styles.inputField}
            onChangeText={this.handlePinCode}
          />
          <DatePicker
            style={{width: 200}}
            date={this.state.date}
            mode="date"
            placeholder="select date"
            format="DD-MM-YYYY"
            minDate="01-01-2020"
            maxDate="31-12-2022"
            confirmBtnText="Ok"
            cancelBtnText="Cancel"
            onDateChange={date => {
              this.setState({date: date});
            }}
          />
          <TouchableOpacity onPress={this.submit}>
            <Text style={styles.btn}>Get the Centers</Text>
          </TouchableOpacity>

          {this.state.locations.length === 0 ? (
            <Text style={{ fontSize: 19, fontWeight: 'bold', marginVertical: 10 }}>No Centers Found</Text>
          ) : (
            <ScrollView>
              <View>
                {this.state.locations.map((location, index) => {
                  return (
                    <View key={index} style={styles.card}>
                      <Text style={{ fontSize: 16, fontWeight: 'bold' }}>{location.name}</Text>
                      <Text>{location.vaccine}</Text>
                      <Text>
                        Available Vaccines: {location.available_capacity}
                      </Text>
                      <Text>Min. Age: {location.min_age_limit}</Text>
                    </View>
                  );
                })}
              </View>
            </ScrollView>
          )}
        </View>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  inputField: {
    width: 400,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: 'black',
    marginVertical: 30,
    paddingLeft: 30,
  },
  btn: {
    backgroundColor: 'black',
    color: 'white',
    padding: 10,
    borderRadius: 20,
    marginVertical: 10,
    elevation: 4,
  },
  card: {
    width: 450,
    backgroundColor: 'white',
    borderRadius: 15,
    elevation: 4,
    margin: 10,
    padding: 10,
  },
});

export default App;
// import React from 'react';
// import {
//   View,
//   TextInput,
//   StyleSheet,
//   TouchableOpacity,
//   Text,
//   ScrollView,
// } from 'react-native';
// import DatePicker from 'react-native-datepicker';

// class App extends React.Component {
  
//   state = {
//     pinCode: null,
//     date: null,
//     locations: [],
//   };

//   handlePinCode = value => {
//     this.setState({
//       pinCode: value,
//     });
//   };

//   submit = () => {
//     fetch(
//       `https://cdn-api.co-vin.in/api/v2/appointment/sessions/public/findByPin?pincode=${this.state.pinCode}&date=${this.state.date}`,
//       {
//         method: 'GET',
//         headers: {
//           'User-Agent':
//             'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.95 Safari/537.36',
//         },
//       },
//     )
//       .then(res => {
//         return res.json();
//       })
//       .then(response => {
//         this.setState({
//           locations: response['sessions'],
//         });
//       })
//       .catch(error => {
//         console.log(error);
//       });
//   };

//   render() {
//     return (
//       <ScrollView>
//       <View>
//         <View style={{alignItems: 'center'}}>
//           <TextInput
//             placeholder="Enter the pincode"
//             keyboardType={'number-pad'}
//             style={styles.inputField}
//             onChangeText={this.handlePinCode}
//           />
//           <DatePicker
//             style={{width: 200}}
//             date={this.state.date}
//             mode="date"
//             placeholder="select date"
//             format="DD-MM-YYYY"
//             minDate="01-01-2020"
//             maxDate="31-12-2022"
//             confirmBtnText="Ok"
//             cancelBtnText="Cancel"
//             onDateChange={date => {
//               this.setState({date: date});
//             }}
//           />
//           <TouchableOpacity onPress={this.submit}>
//             <Text style={styles.btn}>Get the Centers</Text>
//           </TouchableOpacity>

//           {this.state.locations.length === 0 ? (
//             <Text style={{ fontSize: 19, fontWeight: 'bold', marginVertical: 10 }}>No Centers Found</Text>
//           ) : (
//             <ScrollView>
//               <View>
//                 {this.state.locations.map((location, index) => {
//                   return (
//                     <View key={index} style={styles.card}>
//                       <Text style={{ fontSize: 16, fontWeight: 'bold' }}>{location.name}</Text>
//                       <Text>{location.vaccine}</Text>
//                       <Text>
//                         Available Vaccines: {location.available_capacity}
//                       </Text>
//                       <Text>Min. Age: {location.min_age_limit}</Text>
//                     </View>
//                   );
//                 })}
//               </View>
//             </ScrollView>
//           )}
//         </View>
//       </View>
//         </ScrollView>
//     );
//   }
// }

// const styles = StyleSheet.create({
//   inputField: {
//     width: 300,
//     borderRadius: 20,
//     borderWidth: 4,
//     borderColor: 'black',
//     marginVertical: 30,
//     paddingLeft: 30,
//   },
//   btn: {
//     backgroundColor: 'black',
//     color: 'white',
//     padding: 10,
//     borderRadius: 20,
//     marginVertical: 10,
//     elevation: 4,
//   },
//   card: {
//     width: 450,
//     backgroundColor: 'white',
//     borderRadius: 15,
//     elevation: 4,
//     margin: 10,
//     padding: 10,
//   },
// });


// // import * as React from 'react';
// // import { Text, View, StyleSheet, Image } from 'react-native';

// // export default function Vaccination() {
// //   return (
// //     <View style={styles.container}>
// //     <Image style={styles.logo} source={require('../assets/Covid5.jpg')} />
// //       <Text style={styles.paragraph}>
// //         The first mass vaccination programme started in early December 2020 and
// //         the number of vaccination doses administered is updated on a daily basis
// //         here. At least 13 different vaccines (across 4 platforms) have been
// //         administered. The Pfizer/BioNtech Comirnaty vaccine was listed for WHO
// //         Emergency Use Listing (EUL) on 31 December 2020. The SII/Covishield and
// //         AstraZeneca/AZD1222 vaccines (developed by AstraZeneca/Oxford and
// //         manufactured by the State Institute of India and SK Bio respectively)
// //         were given EUL on 16 February. The Janssen/Ad26.COV 2.S developed by
// //         Johnson & Johnson, was listed for EUL on 12 March 2021. The Moderna
// //         COVID-19 vaccine (mRNA 1273) was listed for EUL on 30 April 2021 and the
// //         Sinopharm COVID-19 vaccine was listed for EUL on 7 May 2021. The
// //         Sinopharm vaccine is produced by Beijing Bio-Institute of Biological
// //         Products Co Ltd, subsidiary of China National Biotec Group (CNBG). The
// //         Sinovac-CoronaVac was listed for EUL on 1 June 2021.
// //       </Text>
// //       <Text style={styles.paragraph,{padding:20,margin:20,fontWeight:'bold',fontFamily:'cursive'}}>
// //       Once vaccines are demonstrated to be safe and efficacious, they must be authorized by national regulators, manufactured to exacting standards, and distributed. WHO is working with partners around the world to help coordinate key steps in this process, including to facilitate equitable access to safe and effective COVID-19 vaccines for the billions of people who will need them. More information about COVID-19 vaccine development is available 
// //       </Text>
// //       <Image style={styles.logo} source={require('../assets/covid7.jpg')} />
// //     </View>
// //   );
// // }

// // const styles = StyleSheet.create({
// //   container: {
// //     alignItems: 'center',
// //     justifyContent: 'center',
// //     padding: 24,
// //   },
// //   paragraph: {

// //     marginTop: 0,
// //     fontSize: 14,
// //     fontWeight: 'bold',
// //     textAlign: 'center',
// //     fontFamily:'cursive',
// //   },
// //   logo: {
// //     height: 160,
// //     width: 450,
// //   },
// // });
