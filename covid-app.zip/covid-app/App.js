import React, { useReducer } from 'react';
import { Text, View, StyleSheet, StatusBar,reducer,initialState, } from 'react-native';
import Constants from 'expo-constants';
import Vaccination from './components/Vaccination'

// or any pure javascript modules available in npm

import { Card } from 'react-native-paper';
import db from './config';
import { NavigationContainer } from '@react-navigation/native';
import { createDrawerNavigator } from '@react-navigation/drawer';
const Drawer = createDrawerNavigator();
import login from './components/Loginpage';
import Vedio from './components/Vedio';
import Home from './components/Home';
import Covid from './components/Covid';
import Thought from './components/Thought';
import Symptoms from './components/Symptoms';
import Preventions from './components/Preventions';
export const AppContext = React.createContext();
export default function App() {

  const [state, dispatch] = useReducer(reducer, initialState);

  return (
    <AppContext.Provider value={{state, dispatch}}>
    <View style ={styles.container}>
    <StatusBar barStyle={'light-content'} backgroundColor="#007bff"/>
    <NavigationContainer>
      <Drawer.Navigator initialRouteName="Covid" screenOptions={{headerShown: true}}>
      <Drawer.Screen name="Login" component={login} />
        <Drawer.Screen name="Covid" component={Covid} />
        <Drawer.Screen name="Home" component={Home} />
        <Drawer.Screen name="Motivational Thoughts" component={Thought} />
         <Drawer.Screen name="Vaccination" component={Vaccination} />
         <Drawer.Screen name="Symptoms & Causes" component={Symptoms} />
         <Drawer.Screen name="Prevention" component={Preventions} />
          <Drawer.Screen name="Vedio" component={Vedio} />

       

      </Drawer.Navigator>
    </NavigationContainer>
    
    
    </View>
    </AppContext.Provider>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    paddingTop: Constants.statusBarHeight,
    // backgroundColor: 'blue',
  },
});